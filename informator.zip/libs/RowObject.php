<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RowObject
 *
 * @author edinson
 */
abstract class RowObject {

    public abstract function fetch(array $row = array());
}

?>
